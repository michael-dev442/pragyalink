const express = require('express');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views', 'index.html')));
app.get('/passenger', (req, res) => res.sendFile(path.join(__dirname, 'views', 'passenger.html')));
app.get('/rider', (req, res) => res.sendFile(path.join(__dirname, 'views', 'rider.html')));
app.get('/mechanic', (req, res) => res.sendFile(path.join(__dirname, 'views', 'mechanic.html')));

// --- AUTHENTICATION API ENDPOINTS ---

// Signup Route
app.post('/api/signup', (req, res) => {
    const { username, password, fullName, contact, role } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: "Username and password required" });
    }

    const query = `INSERT INTO users (username, password, fullName, contact, role) VALUES (?, ?, ?, ?, ?)`;
    db.run(query, [username, password, fullName, contact, role || 'passenger'], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                return res.status(400).json({ error: "Username already exists!" });
            }
            return res.status(500).json({ error: "Database error during signup" });
        }
        res.json({ success: true, message: "Account created successfully!" });
    });
});

// Login Route
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    const query = `SELECT * FROM users WHERE username = ? AND password = ?`;
    db.get(query, [username, password], (err, user) => {
        if (err) return res.status(500).json({ error: "Database error" });
        if (!user) {
            return res.status(401).json({ error: "Invalid username or password!" });
        }
        res.json({ success: true, user: { username: user.username, fullName: user.fullName, contact: user.contact } });
    });
});

app.listen(PORT, () => {
    console.log(`🚀 PragyaLink running at http://localhost:${PORT}`);
});

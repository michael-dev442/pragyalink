const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// =========================================================
// 📦 PERSISTENT JSON FILE STORAGE
// =========================================================
const DB_FILE = path.join(__dirname, 'database.json');

function loadDatabase() {
    if (!fs.existsSync(DB_FILE)) {
        const initialData = { servicePassports: {}, rideHistory: [], registeredFleet: {} };
        fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
        return initialData;
    }
    try {
        const data = fs.readFileSync(DB_FILE, 'utf8');
        const parsed = JSON.parse(data);
        // Guard against a partially-shaped file from an older version
        parsed.servicePassports = parsed.servicePassports || {};
        parsed.rideHistory = parsed.rideHistory || [];
        parsed.registeredFleet = parsed.registeredFleet || {};
        return parsed;
    } catch (e) {
        console.error("Error reading database.json, re-initializing...", e);
        return { servicePassports: {}, rideHistory: [], registeredFleet: {} };
    }
}

function saveDatabase(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

let db = loadDatabase();

// =========================================================
// 🧠 RUNTIME STATE
// =========================================================
const activeRiders = {};       // socket.id -> live driver telemetry
const activeWorkshops = {};    // socket.id -> registered mechanic workshop
const fleetOwnerSockets = {};  // socket.id -> fleet owner code (dashboard viewers)

const SERVICE_INTERVAL_KM = 1500;
const INDEPENDENT_CODE = 'INDEPENDENT';

function calculateDistanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function isFleetLinked(fleetOwnerCode) {
    return !!fleetOwnerCode && fleetOwnerCode.trim().toUpperCase() !== INDEPENDENT_CODE;
}

// Is this plate present in the owner's registered vehicle list?
function isPlateRegisteredToFleet(fleetOwnerCode, plateNumber) {
    const list = db.registeredFleet[fleetOwnerCode] || [];
    return list.some(v => v.plateNumber === plateNumber);
}

function ensurePassport(plate, defaults = {}) {
    if (!db.servicePassports[plate]) {
        db.servicePassports[plate] = {
            currentServiceKm: 0.0,
            totalLifetimeKm: 0.0,
            dailyLeaseTarget: defaults.dailyTargetGhs || 120,
            vin: defaults.vin || null,
            model: defaults.model || null,
            ownerCode: defaults.ownerCode || null,
            serviceHistory: []
        };
    }
    return db.servicePassports[plate];
}

// Build the filtered payload a fleet-owner dashboard (owner.html / fleet.html) needs:
// every registered vehicle, cross-referenced with whichever of them are currently online.
function emitFleetToOwner(ownerSocketId) {
    const fleetCode = fleetOwnerSockets[ownerSocketId];
    if (!fleetCode) return;

    const liveFleet = Object.values(activeRiders).filter(
        rider => rider.fleetOwnerCode && rider.fleetOwnerCode.trim() === fleetCode.trim()
    );

    const savedFleetVehicles = (db.registeredFleet[fleetCode] || []).map(v => {
        const passport = db.servicePassports[v.plateNumber] || null;
        return { ...v, passport };
    });

    io.to(ownerSocketId).emit('current-riders', {
        activeDrivers: liveFleet,
        registeredVehicles: savedFleetVehicles,
        fleetCode
    });
}

function broadcastFleetUpdates() {
    Object.keys(fleetOwnerSockets).forEach(socketId => emitFleetToOwner(socketId));
}

// =========================================================
// 🌐 REST API
// =========================================================
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views', 'index.html')));
app.get('/passenger', (req, res) => res.sendFile(path.join(__dirname, 'views', 'passenger.html')));
app.get('/rider', (req, res) => res.sendFile(path.join(__dirname, 'views', 'rider.html')));
app.get('/mechanic', (req, res) => res.sendFile(path.join(__dirname, 'views', 'mechanic.html')));
app.get('/owner', (req, res) => res.sendFile(path.join(__dirname, 'views', 'owner.html')));
app.get('/fleet', (req, res) => res.sendFile(path.join(__dirname, 'views', 'fleet.html')));

app.get('/api/passenger/history/:phone', (req, res) => {
    const phone = req.params.phone;
    const history = db.rideHistory.filter(ride => ride.passengerPhone === phone);
    res.json(history);
});

// =========================================================
// 📡 REALTIME ENGINE — single connection handler
// =========================================================
io.on('connection', (socket) => {
    console.log(`🔌 Client connected: ${socket.id}`);

    // Passenger app requests a full snapshot on connect (fixes the "cold start" gap where
    // drivers already online wouldn't appear until their next telemetry tick)
    socket.on('request-online-drivers', () => {
        socket.emit('current-riders', Object.values(activeRiders));
    });

    // ---- Fleet owner dashboard session (used by owner.html AND fleet.html) ----
    socket.on('register-owner-session', (ownerCode) => {
        if (!ownerCode || !ownerCode.trim()) return;
        fleetOwnerSockets[socket.id] = ownerCode.trim();
        emitFleetToOwner(socket.id);
    });

    socket.on('owner-register-vehicle', (vData) => {
        if (!vData || !vData.ownerCode || !vData.plateNumber) return;
        const ownerCode = vData.ownerCode.trim();
        const plate = vData.plateNumber.toUpperCase();
        const record = { ...vData, plateNumber: plate, ownerCode };

        if (!db.registeredFleet[ownerCode]) db.registeredFleet[ownerCode] = [];
        const idx = db.registeredFleet[ownerCode].findIndex(v => v.plateNumber === plate);
        if (idx >= 0) db.registeredFleet[ownerCode][idx] = record;
        else db.registeredFleet[ownerCode].push(record);

        const passport = ensurePassport(plate, record);
        passport.vin = record.vin;
        passport.model = record.model;
        passport.dailyLeaseTarget = record.dailyTargetGhs || passport.dailyLeaseTarget;
        passport.ownerCode = ownerCode;
        passport.assignedDriverPhone = record.assignedDriverPhone || passport.assignedDriverPhone;

        saveDatabase(db);
        emitFleetToOwner(socket.id);

        // If a driver for this plate is already online, refresh their registration flag live
        const liveEntry = Object.values(activeRiders).find(r => r.plateNumber === plate);
        if (liveEntry) {
            liveEntry.isRegisteredVehicle = true;
            broadcastFleetUpdates();
        }
    });

    socket.on('owner-edit-vehicle', (vData) => {
        if (!vData || !vData.ownerCode || !vData.plateNumber) return;
        const ownerCode = vData.ownerCode.trim();
        const plate = vData.plateNumber.toUpperCase();

        if (db.registeredFleet[ownerCode]) {
            const idx = db.registeredFleet[ownerCode].findIndex(v => v.plateNumber === plate);
            if (idx >= 0) db.registeredFleet[ownerCode][idx] = { ...vData, plateNumber: plate, ownerCode };
        }

        if (db.servicePassports[plate]) {
            db.servicePassports[plate].dailyLeaseTarget = vData.dailyTargetGhs;
            db.servicePassports[plate].assignedDriverPhone = vData.assignedDriverPhone;
        }

        saveDatabase(db);
        emitFleetToOwner(socket.id);
    });

    // ---- Driver presence & telemetry ----

    // One-shot "I am now online" announcement (also used for session-restore-on-refresh)
    socket.on('driver-go-online', (driverData) => {
        registerDriverTelemetry(socket, driverData, { isGoOnlineEvent: true });
    });

    // Continuous GPS + engine-health telemetry stream (also doubles as the heartbeat)
    socket.on('update-rider-location', (riderData) => {
        registerDriverTelemetry(socket, riderData, { isGoOnlineEvent: false });
    });

    // Legacy driver session recovery hook — kept for backward compatibility
    socket.on('register-rider', (riderData) => {
        registerDriverTelemetry(socket, riderData, { isGoOnlineEvent: true });
    });

    function registerDriverTelemetry(socket, data, opts) {
        if (!data || !data.plateNumber) return;
        const plate = data.plateNumber.toUpperCase();
        const fleetOwnerCode = (data.fleetOwnerCode || INDEPENDENT_CODE).trim();
        const fleetLinked = isFleetLinked(fleetOwnerCode);

        const passport = ensurePassport(plate);

        // Track distance since the last known position, feed the service passport
        const prev = activeRiders[socket.id];
        if (prev && prev.lat != null && prev.lng != null && data.lat != null && data.lng != null) {
            const deltaKm = calculateDistanceKm(prev.lat, prev.lng, data.lat, data.lng);
            if (deltaKm > 0.005 && deltaKm < 2.0) {
                passport.currentServiceKm += deltaKm;
                passport.totalLifetimeKm += deltaKm;
                saveDatabase(db);
            }
        }

        const existingShiftEarnings = prev ? prev.shiftEarnings : 0.00;

        activeRiders[socket.id] = {
            username: data.username || data.driverName || prev?.username || 'Driver',
            fullName: data.fullName || data.driverName || prev?.fullName || 'Driver',
            contact: data.contact || data.driverPhone || prev?.contact || null,
            plateNumber: plate,
            fleetOwnerCode,
            operatingMode: data.operatingMode || (fleetLinked ? 'FLEET' : 'OWNER'),
            lat: data.lat != null ? data.lat : prev?.lat,
            lng: data.lng != null ? data.lng : prev?.lng,
            socketId: socket.id,
            status: prev?.status || 'IDLE',
            shiftEarnings: existingShiftEarnings,
            engineHealth: data.engineHealth || prev?.engineHealth || null,
            isRegisteredVehicle: fleetLinked ? isPlateRegisteredToFleet(fleetOwnerCode, plate) : true,
            passport,
            lastSeen: new Date().toISOString()
        };

        socket.emit('passport-update', passport);
        io.emit('rider-location-updated', activeRiders[socket.id]);
        broadcastFleetUpdates();
    }

    // Driver explicitly goes offline without disconnecting the socket
    socket.on('driver-go-offline', () => {
        if (activeRiders[socket.id]) {
            delete activeRiders[socket.id];
            io.emit('rider-disconnected', socket.id);
            broadcastFleetUpdates();
        }
    });

    // ---- Dispatch lifecycle ----

    socket.on('request-ride', (reqData) => {
        const targetSocketId = Object.keys(activeRiders).find(
            id => activeRiders[id].username === reqData.targetRiderUsername
        );
        if (targetSocketId) {
            io.to(targetSocketId).emit('incoming-ride-request', { ...reqData, passengerSocketId: socket.id });
        }
    });

    // Driver accepts OR declines a dispatch (status: 'accepted' | 'declined')
    socket.on('respond-ride-request', (resData) => {
        const rider = activeRiders[socket.id];
        if (rider && resData.status === 'accepted') {
            rider.status = 'EN_ROUTE';
            io.emit('rider-location-updated', rider);
            broadcastFleetUpdates();
        }
        if (resData.passengerSocketId) {
            io.to(resData.passengerSocketId).emit('ride-request-response', resData);
        }
    });

    socket.on('start-trip-meter', (data) => {
        const rider = activeRiders[socket.id];
        if (rider) {
            rider.status = 'ON_TRIP';
            io.emit('rider-location-updated', rider);
            broadcastFleetUpdates();
        }
        io.emit('trip-meter-started', data);
    });

    socket.on('end-trip', (tripData) => {
        const rider = activeRiders[socket.id];
        if (rider) {
            const fareGhs = parseFloat(tripData.fareGhs || 0);
            rider.shiftEarnings += fareGhs;
            rider.status = 'IDLE';

            const tripRecord = {
                tripId: 'TRIP-' + Date.now(),
                riderName: rider.fullName,
                plateNumber: rider.plateNumber,
                passengerPhone: tripData.passengerPhone || null,
                fareGhs,
                distanceDrivenKm: tripData.distanceDrivenKm || null,
                timestamp: new Date().toISOString()
            };
            db.rideHistory.push(tripRecord);
            saveDatabase(db);

            socket.emit('trip-completed-summary', {
                fareGhs,
                totalShiftEarnings: rider.shiftEarnings,
                passport: rider.passport
            });

            if (tripData.passengerSocketId) {
                io.to(tripData.passengerSocketId).emit('passenger-trip-ended', { fareGhs, tripRecord });
            }

            io.emit('rider-location-updated', rider);
            broadcastFleetUpdates();
        }
    });

    // Driver confirms an oil change / service was completed
    socket.on('confirm-service-reset', (data) => {
        if (!data || !data.plateNumber) return;
        const plate = data.plateNumber.toUpperCase();
        const passport = ensurePassport(plate);

        passport.serviceHistory.push({
            resetAtKm: passport.currentServiceKm,
            timestamp: new Date().toISOString()
        });
        passport.currentServiceKm = 0.0;
        saveDatabase(db);

        socket.emit('passport-update', passport);
        broadcastFleetUpdates();
    });

    // ---- Roadside assistance (mechanic <-> driver) ----

    socket.on('register-workshop', (workshopData) => {
        if (!workshopData || !workshopData.shopName) return;
        activeWorkshops[socket.id] = { ...workshopData, socketId: socket.id, isOnline: true };
        console.log(`[Workshop Online] ${workshopData.shopName}`);
    });

    socket.on('workshop-status-update', (data) => {
        if (activeWorkshops[socket.id]) {
            activeWorkshops[socket.id].isOnline = !!(data && data.isOnline);
        }
    });

    socket.on('driver-sos-alert', (sosData) => {
        const rider = activeRiders[socket.id];
        const payload = {
            username: sosData.username || rider?.username,
            fullName: sosData.fullName || rider?.fullName,
            contact: sosData.contact || rider?.contact,
            plateNumber: sosData.plateNumber || rider?.plateNumber,
            issue: sosData.issue || 'Breakdown reported',
            lat: sosData.lat != null ? sosData.lat : rider?.lat,
            lng: sosData.lng != null ? sosData.lng : rider?.lng
        };
        // Broadcast to all currently-online registered workshops
        Object.keys(activeWorkshops).forEach(wsSocketId => {
            if (activeWorkshops[wsSocketId].isOnline !== false) {
                io.to(wsSocketId).emit('driver-sos-alert', payload);
            }
        });
    });

    // ---- Cleanup ----

    socket.on('disconnect', () => {
        if (activeRiders[socket.id]) {
            delete activeRiders[socket.id];
            io.emit('rider-disconnected', socket.id);
            broadcastFleetUpdates();
        }
        if (fleetOwnerSockets[socket.id]) {
            delete fleetOwnerSockets[socket.id];
        }
        if (activeWorkshops[socket.id]) {
            delete activeWorkshops[socket.id];
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 PragyaLink Persistent Server running on port ${PORT}`));
